package com.notifymarquee.overlay

import android.animation.Animator
import android.animation.AnimatorListenerAdapter
import android.animation.ObjectAnimator
import android.content.Context
import android.graphics.Color
import android.graphics.drawable.GradientDrawable
import android.os.Handler
import android.os.Looper
import android.view.LayoutInflater
import android.view.animation.LinearInterpolator
import android.widget.FrameLayout
import android.widget.TextView
import com.notifymarquee.R
import com.notifymarquee.model.NotificationItem
import com.notifymarquee.utils.PreferenceManager

class MarqueeOverlayView(ctx: Context, private val prefs: PreferenceManager) : FrameLayout(ctx) {
    private val tv: TextView
    private val handler = Handler(Looper.getMainLooper())
    private var animator: ObjectAnimator? = null
    private var onComplete: (() -> Unit)? = null

    init {
        LayoutInflater.from(ctx).inflate(R.layout.view_marquee_overlay, this, true)
        tv = findViewById(R.id.tvMarquee)
        applyStyle()
    }

    private fun applyStyle() {
        val bgColor = try { Color.parseColor(prefs.bgColor) } catch (_: Exception) { Color.parseColor("#CC1565C0") }
        val alpha = (prefs.transparency * 255 / 100).coerceIn(0, 255)
        val drawable = GradientDrawable().apply {
            shape = GradientDrawable.RECTANGLE
            setColor(Color.argb(alpha, Color.red(bgColor), Color.green(bgColor), Color.blue(bgColor)))
            cornerRadius = prefs.cornerRadius * resources.displayMetrics.density
        }
        tv.background = drawable
        tv.setTextColor(try { Color.parseColor(prefs.textColor) } catch (_: Exception) { Color.WHITE })
        tv.textSize = prefs.textSize
        val p = (8 * resources.displayMetrics.density).toInt()
        tv.setPadding(p * 2, p, p * 2, p)
    }

    fun setNotification(item: NotificationItem) {
        tv.text = if (prefs.showAppName) "【${item.appName}】${item.sender}: ${item.content}"
                  else "${item.sender}: ${item.content}"
    }

    fun setOnCompleteListener(l: () -> Unit) { onComplete = l }

    fun start() {
        post {
            val sw = resources.displayMetrics.widthPixels.toFloat()
            val tw = tv.width.toFloat()
            tv.translationX = sw
            val speed = prefs.scrollSpeed.coerceIn(1, 10)
            val pps = 80f + (speed - 1) * 40f
            val dur = (((sw + tw) / pps) * 1000).toLong()
            animator = ObjectAnimator.ofFloat(tv, "translationX", sw, -tw).apply {
                duration = dur; interpolator = LinearInterpolator()
                addListener(object : AnimatorListenerAdapter() {
                    override fun onAnimationEnd(a: Animator) { handler.postDelayed({ onComplete?.invoke() }, 200) }
                })
                start()
            }
            handler.postDelayed({ animator?.cancel(); onComplete?.invoke() }, prefs.displayDuration)
        }
    }

    override fun onDetachedFromWindow() { super.onDetachedFromWindow(); animator?.cancel(); handler.removeCallbacksAndMessages(null) }
}
