package com.notifymarquee.service

import android.app.Notification
import android.content.Intent
import android.service.notification.NotificationListenerService
import android.service.notification.StatusBarNotification
import com.notifymarquee.model.NotificationItem
import com.notifymarquee.utils.PreferenceManager
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.SupervisorJob
import kotlinx.coroutines.launch

/**
 * Service lắng nghe thông báo từ các ứng dụng khác.
 * Sử dụng NotificationListenerService - không cần root.
 */
class NotificationListener : NotificationListenerService() {

    companion object {
        const val ACTION_NEW_NOTIFICATION = "com.notifymarquee.NEW_NOTIFICATION"
        const val EXTRA_APP_PACKAGE = "extra_app_package"
        const val EXTRA_APP_NAME = "extra_app_name"
        const val EXTRA_SENDER = "extra_sender"
        const val EXTRA_CONTENT = "extra_content"
        const val EXTRA_TIMESTAMP = "extra_timestamp"
        const val EXTRA_IS_PRIORITY = "extra_is_priority"

        // Các package phải bỏ qua (chính ứng dụng, system)
        private val IGNORED_PACKAGES = setOf(
            "android",
            "com.android.systemui",
            "com.android.settings",
            "com.google.android.gms"
        )
    }

    private val serviceScope = CoroutineScope(Dispatchers.IO + SupervisorJob())
    private lateinit var prefManager: PreferenceManager

    override fun onCreate() {
        super.onCreate()
        prefManager = PreferenceManager(this)
    }

    /**
     * Được gọi khi có thông báo mới xuất hiện
     */
    override fun onNotificationPosted(sbn: StatusBarNotification) {
        super.onNotificationPosted(sbn)

        // Chỉ xử lý khi dịch vụ đang bật
        if (!prefManager.isServiceEnabled) return

        val packageName = sbn.packageName

        // Bỏ qua các package hệ thống
        if (packageName in IGNORED_PACKAGES) return

        // Chỉ xử lý package nằm trong danh sách bộ lọc đã bật
        val enabledPackages = prefManager.getEnabledPackages()
        if (enabledPackages.isNotEmpty() && packageName !in enabledPackages) return

        // Trích xuất thông tin từ notification
        val extras = sbn.notification.extras ?: return
        val title = extras.getString(Notification.EXTRA_TITLE) ?: return
        val text = extras.getCharSequence(Notification.EXTRA_TEXT)?.toString() ?: return

        // Bỏ qua nếu nội dung trống hoặc chỉ là số lượng tin nhắn
        if (text.isBlank()) return
        if (text.matches(Regex("\\d+ tin nhắn.*"))) return

        val appName = getAppName(packageName)
        val isPriority = prefManager.isPriorityContact(title)

        val item = NotificationItem(
            appPackage = packageName,
            appName = appName,
            sender = title,
            content = text,
            timestamp = sbn.postTime,
            isPriority = isPriority
        )

        // Lưu vào CSDL và phát broadcast để hiển thị overlay
        serviceScope.launch {
            saveAndBroadcast(item)
        }
    }

    /**
     * Lưu thông báo và gửi broadcast đến MarqueeOverlayService
     */
    private suspend fun saveAndBroadcast(item: NotificationItem) {
        // Broadcast để MarqueeOverlayService nhận và hiển thị
        val intent = Intent(ACTION_NEW_NOTIFICATION).apply {
            setPackage(packageName)
            putExtra(EXTRA_APP_PACKAGE, item.appPackage)
            putExtra(EXTRA_APP_NAME, item.appName)
            putExtra(EXTRA_SENDER, item.sender)
            putExtra(EXTRA_CONTENT, item.content)
            putExtra(EXTRA_TIMESTAMP, item.timestamp)
            putExtra(EXTRA_IS_PRIORITY, item.isPriority)
        }
        sendBroadcast(intent)
    }

    /**
     * Lấy tên ứng dụng từ package name
     */
    private fun getAppName(packageName: String): String {
        return try {
            val pm = packageManager
            val info = pm.getApplicationInfo(packageName, 0)
            pm.getApplicationLabel(info).toString()
        } catch (e: Exception) {
            packageName.substringAfterLast(".")
        }
    }

    override fun onNotificationRemoved(sbn: StatusBarNotification) {
        // Không cần xử lý khi thông báo bị xóa
    }
}
