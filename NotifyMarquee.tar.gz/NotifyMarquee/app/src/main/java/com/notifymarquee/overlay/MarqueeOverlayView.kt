package com.notifymarquee.overlay

import android.animation.Animator
import android.animation.AnimatorListenerAdapter
import android.animation.ObjectAnimator
import android.content.Context
import android.graphics.Color
import android.graphics.drawable.GradientDrawable
import android.os.Handler
import android.os.Looper
import android.view.LayoutInflater
import android.view.animation.LinearInterpolator
import android.widget.FrameLayout
import android.widget.TextView
import com.notifymarquee.R
import com.notifymarquee.model.NotificationItem
import com.notifymarquee.utils.PreferenceManager

/**
 * Custom View hiển thị thanh chạy ngang màn hình (Marquee Banner).
 * Chạy từ phải sang trái với hiệu ứng mượt mà, không giật lag.
 */
class MarqueeOverlayView(
    context: Context,
    private val prefManager: PreferenceManager
) : FrameLayout(context) {

    private val tvMarquee: TextView
    private val handler = Handler(Looper.getMainLooper())
    private var marqueeAnimator: ObjectAnimator? = null
    private var onCompleteListener: (() -> Unit)? = null

    init {
        LayoutInflater.from(context).inflate(R.layout.view_marquee_overlay, this, true)
        tvMarquee = findViewById(R.id.tvMarquee)
        applyStyle()
    }

    /**
     * Áp dụng cài đặt hiển thị từ PreferenceManager
     */
    private fun applyStyle() {
        // Màu nền + bo góc
        val bgColor = try {
            Color.parseColor(prefManager.bgColor)
        } catch (e: Exception) {
            Color.parseColor("#CC1565C0")
        }
        val alpha = (prefManager.transparency * 255 / 100).coerceIn(0, 255)
        val bgWithAlpha = Color.argb(alpha, Color.red(bgColor), Color.green(bgColor), Color.blue(bgColor))

        val drawable = GradientDrawable().apply {
            shape = GradientDrawable.RECTANGLE
            setColor(bgWithAlpha)
            cornerRadius = prefManager.cornerRadius * resources.displayMetrics.density
        }
        tvMarquee.background = drawable

        // Màu chữ và kích thước
        val textColor = try {
            Color.parseColor(prefManager.textColor)
        } catch (e: Exception) {
            Color.WHITE
        }
        tvMarquee.setTextColor(textColor)
        tvMarquee.textSize = prefManager.textSize

        val padding = (8 * resources.displayMetrics.density).toInt()
        tvMarquee.setPadding(padding * 2, padding, padding * 2, padding)
    }

    /**
     * Thiết lập nội dung thông báo
     */
    fun setNotification(item: NotificationItem) {
        val displayText = if (prefManager.showAppName) {
            "【${item.appName}】${item.sender}: ${item.content}"
        } else {
            "${item.sender}: ${item.content}"
        }
        tvMarquee.text = displayText
    }

    /**
     * Callback khi animation chạy xong
     */
    fun setOnMarqueeCompleteListener(listener: () -> Unit) {
        onCompleteListener = listener
    }

    /**
     * Bắt đầu animation chạy marquee từ phải sang trái
     */
    fun startMarquee() {
        // Đợi view được đo xong
        post {
            val screenWidth = resources.displayMetrics.widthPixels.toFloat()
            val textWidth = tvMarquee.width.toFloat()

            // Bắt đầu từ ngoài màn hình bên phải
            tvMarquee.translationX = screenWidth

            // Tính thời gian dựa trên tốc độ cài đặt (1-10)
            // speed 1 = chậm (rất nhiều thời gian), speed 10 = nhanh
            val speed = prefManager.scrollSpeed.coerceIn(1, 10)
            val pixelsPerSecond = 80f + (speed - 1) * 40f // 80-440 px/s
            val totalDistance = screenWidth + textWidth
            val durationMs = ((totalDistance / pixelsPerSecond) * 1000).toLong()

            marqueeAnimator = ObjectAnimator.ofFloat(
                tvMarquee,
                "translationX",
                screenWidth,
                -textWidth
            ).apply {
                this.duration = durationMs
                interpolator = LinearInterpolator()
                addListener(object : AnimatorListenerAdapter() {
                    override fun onAnimationEnd(animation: Animator) {
                        // Ẩn và thông báo hoàn tất
                        handler.postDelayed({
                            onCompleteListener?.invoke()
                        }, 200)
                    }
                })
                start()
            }

            // Tự động ẩn sau thời gian displayDuration dù chưa chạy hết
            handler.postDelayed({
                finishMarquee()
            }, prefManager.displayDuration)
        }
    }

    /**
     * Kết thúc marquee sớm (khi timeout)
     */
    private fun finishMarquee() {
        marqueeAnimator?.cancel()
        onCompleteListener?.invoke()
    }

    override fun onDetachedFromWindow() {
        super.onDetachedFromWindow()
        marqueeAnimator?.cancel()
        handler.removeCallbacksAndMessages(null)
    }
}
