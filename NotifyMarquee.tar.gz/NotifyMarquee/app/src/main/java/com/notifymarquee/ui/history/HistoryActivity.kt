package com.notifymarquee.ui.history

import android.content.Intent
import android.net.Uri
import android.os.Bundle
import android.provider.MediaStore
import android.text.Editable
import android.text.TextWatcher
import android.view.View
import androidx.activity.viewModels
import androidx.appcompat.app.AppCompatActivity
import androidx.lifecycle.lifecycleScope
import com.google.android.material.dialog.MaterialAlertDialogBuilder
import com.notifymarquee.R
import com.notifymarquee.databinding.ActivityHistoryBinding
import com.notifymarquee.viewmodel.HistoryViewModel
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext
import java.io.File

/**
 * Màn hình lịch sử thông báo - hiển thị, tìm kiếm, xóa, xuất dữ liệu
 */
class HistoryActivity : AppCompatActivity() {

    private lateinit var binding: ActivityHistoryBinding
    private val viewModel: HistoryViewModel by viewModels()
    private lateinit var adapter: NotificationHistoryAdapter

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        binding = ActivityHistoryBinding.inflate(layoutInflater)
        setContentView(binding.root)

        setSupportActionBar(binding.toolbar)
        supportActionBar?.setDisplayHomeAsUpEnabled(true)
        binding.toolbar.setNavigationOnClickListener { finish() }

        setupRecyclerView()
        setupSearch()
        setupObservers()
        setupListeners()
    }

    private fun setupRecyclerView() {
        adapter = NotificationHistoryAdapter(
            onDelete = { id -> viewModel.deleteNotification(id) }
        )
        binding.recyclerView.adapter = adapter
        binding.recyclerView.layoutManager = androidx.recyclerview.widget.LinearLayoutManager(this)
    }

    private fun setupSearch() {
        binding.etSearch.addTextChangedListener(object : TextWatcher {
            override fun beforeTextChanged(s: CharSequence?, start: Int, count: Int, after: Int) {}
            override fun onTextChanged(s: CharSequence?, start: Int, before: Int, count: Int) {
                viewModel.search(s?.toString() ?: "")
            }
            override fun afterTextChanged(s: Editable?) {}
        })
    }

    private fun setupObservers() {
        viewModel.notifications.observe(this) { list ->
            adapter.submitList(list)
            binding.tvEmpty.visibility = if (list.isEmpty()) View.VISIBLE else View.GONE
            binding.tvCount.text = "${list.size} thông báo"
        }
    }

    private fun setupListeners() {
        // Xóa tất cả
        binding.btnClearAll.setOnClickListener {
            MaterialAlertDialogBuilder(this)
                .setTitle("Xóa lịch sử")
                .setMessage("Xóa toàn bộ ${adapter.itemCount} thông báo? Không thể hoàn tác.")
                .setPositiveButton("Xóa") { _, _ -> viewModel.deleteAll() }
                .setNegativeButton("Huỷ", null)
                .show()
        }

        // Xuất dữ liệu
        binding.btnExport.setOnClickListener {
            exportData()
        }
    }

    private fun exportData() {
        lifecycleScope.launch {
            val csvContent = viewModel.exportAsCsv()
            withContext(Dispatchers.IO) {
                val file = File(getExternalFilesDir(null), "notify_history_${System.currentTimeMillis()}.csv")
                file.writeText(csvContent, Charsets.UTF_8)
                withContext(Dispatchers.Main) {
                    shareFile(file)
                }
            }
        }
    }

    private fun shareFile(file: File) {
        val uri = androidx.core.content.FileProvider.getUriForFile(
            this,
            "${packageName}.fileprovider",
            file
        )
        val shareIntent = Intent(Intent.ACTION_SEND).apply {
            type = "text/csv"
            putExtra(Intent.EXTRA_STREAM, uri)
            addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION)
        }
        startActivity(Intent.createChooser(shareIntent, "Xuất lịch sử thông báo"))
    }
}
