package com.notifymarquee.utils

import java.text.SimpleDateFormat
import java.util.*

/**
 * Tiện ích xử lý thời gian
 */
object TimeUtils {

    private val timeFormat = SimpleDateFormat("HH:mm", Locale.getDefault())
    private val dateTimeFormat = SimpleDateFormat("dd/MM/yyyy HH:mm", Locale.getDefault())
    private val dateFormat = SimpleDateFormat("dd/MM/yyyy", Locale.getDefault())

    /**
     * Trả về chuỗi thời gian thân thiện (vd: "Vừa xong", "5 phút trước", "14:30")
     */
    fun getRelativeTime(timestamp: Long): String {
        val now = System.currentTimeMillis()
        val diff = now - timestamp

        return when {
            diff < 60_000 -> "Vừa xong"
            diff < 3_600_000 -> "${diff / 60_000} phút trước"
            diff < 86_400_000 -> timeFormat.format(Date(timestamp))
            else -> dateTimeFormat.format(Date(timestamp))
        }
    }

    /**
     * Lấy timestamp đầu ngày hôm nay (00:00:00)
     */
    fun getStartOfToday(): Long {
        val cal = Calendar.getInstance()
        cal.set(Calendar.HOUR_OF_DAY, 0)
        cal.set(Calendar.MINUTE, 0)
        cal.set(Calendar.SECOND, 0)
        cal.set(Calendar.MILLISECOND, 0)
        return cal.timeInMillis
    }

    fun formatDateTime(timestamp: Long): String = dateTimeFormat.format(Date(timestamp))
    fun formatDate(timestamp: Long): String = dateFormat.format(Date(timestamp))
}
