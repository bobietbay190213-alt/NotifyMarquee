package com.notifymarquee.ui.home

import android.content.Intent
import android.os.Bundle
import android.view.Menu
import android.view.MenuItem
import androidx.activity.viewModels
import androidx.appcompat.app.AppCompatActivity
import com.google.android.material.dialog.MaterialAlertDialogBuilder
import com.notifymarquee.R
import com.notifymarquee.databinding.ActivityMainBinding
import com.notifymarquee.ui.history.HistoryActivity
import com.notifymarquee.ui.settings.SettingsActivity
import com.notifymarquee.utils.PermissionUtils
import com.notifymarquee.viewmodel.HomeViewModel

/**
 * Màn hình chính - điều khiển bật/tắt dịch vụ và hiển thị trạng thái
 */
class MainActivity : AppCompatActivity() {

    private lateinit var binding: ActivityMainBinding
    private val viewModel: HomeViewModel by viewModels()

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        binding = ActivityMainBinding.inflate(layoutInflater)
        setContentView(binding.root)
        setSupportActionBar(binding.toolbar)

        setupObservers()
        setupListeners()
    }

    override fun onResume() {
        super.onResume()
        viewModel.checkPermissions()
        viewModel.loadServiceState()
    }

    private fun setupObservers() {
        // Trạng thái dịch vụ
        viewModel.serviceRunning.observe(this) { running ->
            binding.switchService.isChecked = running
            binding.tvServiceStatus.text = if (running) "Đang hoạt động" else "Đã tắt"
            binding.ivServiceIndicator.setImageResource(
                if (running) R.drawable.ic_circle_active else R.drawable.ic_circle_inactive
            )
        }

        // Trạng thái quyền
        viewModel.permissionStatus.observe(this) { status ->
            updatePermissionCard(
                binding.cardNotificationAccess,
                binding.ivPermNotification,
                binding.tvPermNotificationStatus,
                status.hasNotificationAccess
            )
            updatePermissionCard(
                binding.cardOverlay,
                binding.ivPermOverlay,
                binding.tvPermOverlayStatus,
                status.hasOverlayPermission
            )

            // Disable switch nếu chưa đủ quyền
            binding.switchService.isEnabled = status.allGranted
            if (!status.allGranted) {
                binding.tvPermissionHint.visibility = android.view.View.VISIBLE
            } else {
                binding.tvPermissionHint.visibility = android.view.View.GONE
            }
        }

        // Số thông báo hôm nay
        viewModel.todayNotificationCount.observe(this) { count ->
            binding.tvTodayCount.text = count.toString()
        }
    }

    private fun setupListeners() {
        // Toggle bật/tắt dịch vụ
        binding.switchService.setOnCheckedChangeListener { _, isChecked ->
            val status = viewModel.permissionStatus.value
            if (isChecked && status?.allGranted == false) {
                binding.switchService.isChecked = false
                showPermissionDialog()
                return@setOnCheckedChangeListener
            }
            viewModel.toggleService(isChecked)
        }

        // Nhấn vào card quyền thông báo
        binding.cardNotificationAccess.setOnClickListener {
            if (viewModel.permissionStatus.value?.hasNotificationAccess == false) {
                PermissionUtils.openNotificationListenerSettings(this)
            }
        }

        // Nhấn vào card quyền overlay
        binding.cardOverlay.setOnClickListener {
            if (viewModel.permissionStatus.value?.hasOverlayPermission == false) {
                PermissionUtils.openOverlaySettings(this)
            }
        }

        // Nút lịch sử
        binding.btnHistory.setOnClickListener {
            startActivity(Intent(this, HistoryActivity::class.java))
        }

        // Nút cài đặt
        binding.btnSettings.setOnClickListener {
            startActivity(Intent(this, SettingsActivity::class.java))
        }
    }

    private fun updatePermissionCard(
        card: com.google.android.material.card.MaterialCardView,
        icon: android.widget.ImageView,
        statusText: android.widget.TextView,
        granted: Boolean
    ) {
        icon.setImageResource(
            if (granted) R.drawable.ic_check_circle else R.drawable.ic_warning
        )
        icon.imageTintList = android.content.res.ColorStateList.valueOf(
            if (granted) getColor(R.color.green_500) else getColor(R.color.orange_500)
        )
        statusText.text = if (granted) "Đã cấp phép" else "Chưa cấp phép - nhấn để cài đặt"
    }

    private fun showPermissionDialog() {
        MaterialAlertDialogBuilder(this)
            .setTitle("Cần cấp quyền")
            .setMessage("Vui lòng cấp đầy đủ quyền để sử dụng ứng dụng:\n\n• Quyền lắng nghe thông báo\n• Quyền hiển thị trên ứng dụng khác")
            .setPositiveButton("Mở cài đặt") { _, _ ->
                val status = viewModel.permissionStatus.value ?: return@setPositiveButton
                if (!status.hasNotificationAccess) {
                    PermissionUtils.openNotificationListenerSettings(this)
                } else if (!status.hasOverlayPermission) {
                    PermissionUtils.openOverlaySettings(this)
                }
            }
            .setNegativeButton("Huỷ", null)
            .show()
    }

    override fun onCreateOptionsMenu(menu: Menu): Boolean {
        menuInflater.inflate(R.menu.main_menu, menu)
        return true
    }

    override fun onOptionsItemSelected(item: MenuItem): Boolean {
        return when (item.itemId) {
            R.id.action_history -> {
                startActivity(Intent(this, HistoryActivity::class.java))
                true
            }
            R.id.action_settings -> {
                startActivity(Intent(this, SettingsActivity::class.java))
                true
            }
            else -> super.onOptionsItemSelected(item)
        }
    }
}
