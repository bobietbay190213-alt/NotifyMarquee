package com.notifymarquee.data.database

import androidx.lifecycle.LiveData
import androidx.room.*

/**
 * DAO - các thao tác với bảng thông báo
 */
@Dao
interface NotificationDao {

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun insert(notification: NotificationEntity): Long

    @Query("SELECT * FROM notifications ORDER BY timestamp DESC")
    fun getAllNotifications(): LiveData<List<NotificationEntity>>

    @Query("SELECT * FROM notifications ORDER BY timestamp DESC LIMIT :limit")
    suspend fun getRecentNotifications(limit: Int = 50): List<NotificationEntity>

    @Query("""
        SELECT * FROM notifications 
        WHERE (:query = '' OR sender LIKE '%' || :query || '%' OR content LIKE '%' || :query || '%')
        AND (:appFilter = '' OR appPackage = :appFilter)
        ORDER BY timestamp DESC
    """)
    fun searchNotifications(query: String, appFilter: String): LiveData<List<NotificationEntity>>

    @Query("SELECT COUNT(*) FROM notifications WHERE timestamp >= :startOfDay")
    fun getTodayCount(startOfDay: Long): LiveData<Int>

    @Query("DELETE FROM notifications WHERE id = :id")
    suspend fun deleteById(id: Long)

    @Query("DELETE FROM notifications")
    suspend fun deleteAll()

    @Query("SELECT * FROM notifications ORDER BY timestamp DESC")
    suspend fun getAllForExport(): List<NotificationEntity>
}
