package com.notifymarquee.model

/**
 * Model cho bộ lọc ứng dụng - quyết định ứng dụng nào được lắng nghe thông báo
 */
data class AppFilter(
    val packageName: String,
    val displayName: String,
    var isEnabled: Boolean
) {
    companion object {
        /**
         * Danh sách mặc định các ứng dụng nhắn tin phổ biến
         */
        fun defaultFilters(): List<AppFilter> = listOf(
            AppFilter("com.facebook.orca", "Messenger", true),
            AppFilter("com.zhiliaoapp.musically", "TikTok", true),
            AppFilter("com.zing.zalo", "Zalo", true),
            AppFilter("org.telegram.messenger", "Telegram", true),
            AppFilter("com.discord", "Discord", true),
            AppFilter("com.facebook.katana", "Facebook", false),
            AppFilter("com.instagram.android", "Instagram", false),
            AppFilter("com.whatsapp", "WhatsApp", false),
            AppFilter("jp.naver.line.android", "Line", false),
            AppFilter("com.viber.voip", "Viber", false)
        )
    }
}
