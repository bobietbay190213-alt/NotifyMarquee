package com.notifymarquee.utils

import android.app.NotificationManager
import android.content.ComponentName
import android.content.Context
import android.content.Intent
import android.net.Uri
import android.os.Build
import android.provider.Settings
import com.notifymarquee.service.NotificationListener

/**
 * Tiện ích kiểm tra và yêu cầu quyền hạn
 */
object PermissionUtils {

    /**
     * Kiểm tra quyền truy cập thông báo (Notification Listener)
     */
    fun hasNotificationListenerPermission(context: Context): Boolean {
        val componentName = ComponentName(context, NotificationListener::class.java)
        val flat = Settings.Secure.getString(
            context.contentResolver,
            "enabled_notification_listeners"
        )
        return flat?.contains(componentName.flattenToString()) == true
    }

    /**
     * Kiểm tra quyền hiển thị trên ứng dụng khác (Overlay)
     */
    fun hasOverlayPermission(context: Context): Boolean {
        return Settings.canDrawOverlays(context)
    }

    /**
     * Kiểm tra quyền thông báo (Android 13+)
     */
    fun hasNotificationPermission(context: Context): Boolean {
        return if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.TIRAMISU) {
            val manager = context.getSystemService(NotificationManager::class.java)
            manager.areNotificationsEnabled()
        } else true
    }

    /**
     * Mở màn hình cài đặt quyền lắng nghe thông báo
     */
    fun openNotificationListenerSettings(context: Context) {
        context.startActivity(Intent(Settings.ACTION_NOTIFICATION_LISTENER_SETTINGS).apply {
            addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
        })
    }

    /**
     * Mở màn hình cài đặt quyền overlay
     */
    fun openOverlaySettings(context: Context) {
        context.startActivity(
            Intent(
                Settings.ACTION_MANAGE_OVERLAY_PERMISSION,
                Uri.parse("package:${context.packageName}")
            ).apply {
                addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
            }
        )
    }
}
