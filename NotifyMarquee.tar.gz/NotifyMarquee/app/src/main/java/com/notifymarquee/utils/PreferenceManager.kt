package com.notifymarquee.utils

import android.content.Context
import android.content.SharedPreferences
import com.notifymarquee.model.AppFilter
import org.json.JSONArray
import org.json.JSONObject

/**
 * Quản lý tất cả cài đặt của ứng dụng bằng SharedPreferences
 */
class PreferenceManager(context: Context) {

    companion object {
        private const val PREFS_NAME = "notify_marquee_prefs"

        // Keys cho cài đặt chung
        const val KEY_SERVICE_ENABLED = "service_enabled"
        const val KEY_TEXT_SIZE = "text_size"
        const val KEY_SCROLL_SPEED = "scroll_speed"
        const val KEY_TRANSPARENCY = "transparency"
        const val KEY_POSITION_Y = "position_y"
        const val KEY_DISPLAY_DURATION = "display_duration"
        const val KEY_CORNER_RADIUS = "corner_radius"
        const val KEY_TEXT_COLOR = "text_color"
        const val KEY_BG_COLOR = "bg_color"
        const val KEY_APP_FILTERS = "app_filters"
        const val KEY_PRIORITY_CONTACTS = "priority_contacts"
        const val KEY_SHOW_APP_NAME = "show_app_name"
        const val KEY_SOUND_ENABLED = "sound_enabled"

        // Giá trị mặc định
        const val DEFAULT_TEXT_SIZE = 14f
        const val DEFAULT_SCROLL_SPEED = 5  // 1 (chậm) -> 10 (nhanh)
        const val DEFAULT_TRANSPARENCY = 85 // phần trăm không trong suốt
        const val DEFAULT_DISPLAY_DURATION = 8000L // ms
        const val DEFAULT_CORNER_RADIUS = 8f
        const val DEFAULT_TEXT_COLOR = "#FFFFFF"
        const val DEFAULT_BG_COLOR = "#CC1565C0"
    }

    private val prefs: SharedPreferences =
        context.getSharedPreferences(PREFS_NAME, Context.MODE_PRIVATE)

    // ── Bật/tắt dịch vụ ──────────────────────────────────────────────────────
    var isServiceEnabled: Boolean
        get() = prefs.getBoolean(KEY_SERVICE_ENABLED, false)
        set(value) = prefs.edit().putBoolean(KEY_SERVICE_ENABLED, value).apply()

    // ── Cài đặt hiển thị ─────────────────────────────────────────────────────
    var textSize: Float
        get() = prefs.getFloat(KEY_TEXT_SIZE, DEFAULT_TEXT_SIZE)
        set(value) = prefs.edit().putFloat(KEY_TEXT_SIZE, value).apply()

    var scrollSpeed: Int
        get() = prefs.getInt(KEY_SCROLL_SPEED, DEFAULT_SCROLL_SPEED)
        set(value) = prefs.edit().putInt(KEY_SCROLL_SPEED, value).apply()

    var transparency: Int
        get() = prefs.getInt(KEY_TRANSPARENCY, DEFAULT_TRANSPARENCY)
        set(value) = prefs.edit().putInt(KEY_TRANSPARENCY, value).apply()

    var positionY: Int
        get() = prefs.getInt(KEY_POSITION_Y, 100) // pixels từ đỉnh màn hình
        set(value) = prefs.edit().putInt(KEY_POSITION_Y, value).apply()

    var displayDuration: Long
        get() = prefs.getLong(KEY_DISPLAY_DURATION, DEFAULT_DISPLAY_DURATION)
        set(value) = prefs.edit().putLong(KEY_DISPLAY_DURATION, value).apply()

    var cornerRadius: Float
        get() = prefs.getFloat(KEY_CORNER_RADIUS, DEFAULT_CORNER_RADIUS)
        set(value) = prefs.edit().putFloat(KEY_CORNER_RADIUS, value).apply()

    var textColor: String
        get() = prefs.getString(KEY_TEXT_COLOR, DEFAULT_TEXT_COLOR) ?: DEFAULT_TEXT_COLOR
        set(value) = prefs.edit().putString(KEY_TEXT_COLOR, value).apply()

    var bgColor: String
        get() = prefs.getString(KEY_BG_COLOR, DEFAULT_BG_COLOR) ?: DEFAULT_BG_COLOR
        set(value) = prefs.edit().putString(KEY_BG_COLOR, value).apply()

    var showAppName: Boolean
        get() = prefs.getBoolean(KEY_SHOW_APP_NAME, true)
        set(value) = prefs.edit().putBoolean(KEY_SHOW_APP_NAME, value).apply()

    var soundEnabled: Boolean
        get() = prefs.getBoolean(KEY_SOUND_ENABLED, false)
        set(value) = prefs.edit().putBoolean(KEY_SOUND_ENABLED, value).apply()

    // ── Bộ lọc ứng dụng ──────────────────────────────────────────────────────
    fun getAppFilters(): List<AppFilter> {
        val json = prefs.getString(KEY_APP_FILTERS, null) ?: return AppFilter.defaultFilters()
        return try {
            val arr = JSONArray(json)
            (0 until arr.length()).map { i ->
                val obj = arr.getJSONObject(i)
                AppFilter(
                    packageName = obj.getString("pkg"),
                    displayName = obj.getString("name"),
                    isEnabled = obj.getBoolean("enabled")
                )
            }
        } catch (e: Exception) {
            AppFilter.defaultFilters()
        }
    }

    fun saveAppFilters(filters: List<AppFilter>) {
        val arr = JSONArray()
        filters.forEach { f ->
            arr.put(JSONObject().apply {
                put("pkg", f.packageName)
                put("name", f.displayName)
                put("enabled", f.isEnabled)
            })
        }
        prefs.edit().putString(KEY_APP_FILTERS, arr.toString()).apply()
    }

    fun getEnabledPackages(): Set<String> =
        getAppFilters().filter { it.isEnabled }.map { it.packageName }.toSet()

    // ── Liên hệ ưu tiên ──────────────────────────────────────────────────────
    fun getPriorityContacts(): Set<String> {
        val json = prefs.getString(KEY_PRIORITY_CONTACTS, "[]") ?: "[]"
        return try {
            val arr = JSONArray(json)
            (0 until arr.length()).map { i -> arr.getString(i) }.toSet()
        } catch (e: Exception) {
            emptySet()
        }
    }

    fun savePriorityContacts(contacts: Set<String>) {
        val arr = JSONArray()
        contacts.forEach { arr.put(it) }
        prefs.edit().putString(KEY_PRIORITY_CONTACTS, arr.toString()).apply()
    }

    fun isPriorityContact(name: String): Boolean = getPriorityContacts().contains(name)
}
