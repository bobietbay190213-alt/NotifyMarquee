package com.notifymarquee.data.repository

import android.content.Context
import androidx.lifecycle.LiveData
import com.notifymarquee.data.database.AppDatabase
import com.notifymarquee.data.database.NotificationEntity
import com.notifymarquee.model.NotificationItem
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext

/**
 * Repository - trung gian giữa ViewModel và Database
 */
class NotificationRepository(context: Context) {

    private val dao = AppDatabase.getInstance(context).notificationDao()

    /**
     * Thêm thông báo mới vào CSDL
     */
    suspend fun insert(item: NotificationItem): Long = withContext(Dispatchers.IO) {
        dao.insert(item.toEntity())
    }

    /**
     * Lấy tất cả thông báo (LiveData - tự cập nhật UI)
     */
    fun getAllNotifications(): LiveData<List<NotificationEntity>> = dao.getAllNotifications()

    /**
     * Tìm kiếm thông báo theo từ khóa và bộ lọc ứng dụng
     */
    fun searchNotifications(query: String, appFilter: String): LiveData<List<NotificationEntity>> =
        dao.searchNotifications(query, appFilter)

    /**
     * Đếm số thông báo hôm nay
     */
    fun getTodayCount(startOfDay: Long): LiveData<Int> = dao.getTodayCount(startOfDay)

    /**
     * Xóa thông báo theo ID
     */
    suspend fun deleteById(id: Long) = withContext(Dispatchers.IO) {
        dao.deleteById(id)
    }

    /**
     * Xóa toàn bộ lịch sử
     */
    suspend fun deleteAll() = withContext(Dispatchers.IO) {
        dao.deleteAll()
    }

    /**
     * Xuất toàn bộ dữ liệu
     */
    suspend fun getAllForExport(): List<NotificationEntity> = withContext(Dispatchers.IO) {
        dao.getAllForExport()
    }

    private fun NotificationItem.toEntity() = NotificationEntity(
        appPackage = appPackage,
        appName = appName,
        sender = sender,
        content = content,
        timestamp = timestamp,
        isPriority = isPriority
    )
}
