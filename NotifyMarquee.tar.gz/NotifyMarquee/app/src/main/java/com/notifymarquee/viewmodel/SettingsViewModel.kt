package com.notifymarquee.viewmodel

import android.app.Application
import androidx.lifecycle.AndroidViewModel
import androidx.lifecycle.LiveData
import androidx.lifecycle.MutableLiveData
import com.notifymarquee.model.AppFilter
import com.notifymarquee.utils.PreferenceManager

/**
 * ViewModel cho màn hình Cài đặt
 */
class SettingsViewModel(application: Application) : AndroidViewModel(application) {

    val prefManager = PreferenceManager(application)

    private val _appFilters = MutableLiveData<List<AppFilter>>()
    val appFilters: LiveData<List<AppFilter>> = _appFilters

    private val _priorityContacts = MutableLiveData<Set<String>>()
    val priorityContacts: LiveData<Set<String>> = _priorityContacts

    init {
        loadFilters()
        loadContacts()
    }

    fun loadFilters() {
        _appFilters.value = prefManager.getAppFilters()
    }

    fun loadContacts() {
        _priorityContacts.value = prefManager.getPriorityContacts()
    }

    fun updateAppFilter(index: Int, enabled: Boolean) {
        val current = _appFilters.value?.toMutableList() ?: return
        current[index] = current[index].copy(isEnabled = enabled)
        _appFilters.value = current
        prefManager.saveAppFilters(current)
    }

    fun addPriorityContact(name: String) {
        val current = _priorityContacts.value?.toMutableSet() ?: mutableSetOf()
        current.add(name.trim())
        _priorityContacts.value = current
        prefManager.savePriorityContacts(current)
    }

    fun removePriorityContact(name: String) {
        val current = _priorityContacts.value?.toMutableSet() ?: return
        current.remove(name)
        _priorityContacts.value = current
        prefManager.savePriorityContacts(current)
    }

    // Cài đặt hiển thị
    var textSize: Float
        get() = prefManager.textSize
        set(value) { prefManager.textSize = value }

    var scrollSpeed: Int
        get() = prefManager.scrollSpeed
        set(value) { prefManager.scrollSpeed = value }

    var transparency: Int
        get() = prefManager.transparency
        set(value) { prefManager.transparency = value }

    var displayDuration: Long
        get() = prefManager.displayDuration
        set(value) { prefManager.displayDuration = value }

    var cornerRadius: Float
        get() = prefManager.cornerRadius
        set(value) { prefManager.cornerRadius = value }

    var showAppName: Boolean
        get() = prefManager.showAppName
        set(value) { prefManager.showAppName = value }

    var positionY: Int
        get() = prefManager.positionY
        set(value) { prefManager.positionY = value }
}
