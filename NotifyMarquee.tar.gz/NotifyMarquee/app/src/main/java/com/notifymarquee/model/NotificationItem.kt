package com.notifymarquee.model

/**
 * Model đại diện cho một thông báo đã nhận
 */
data class NotificationItem(
    val id: Long = 0,
    val appPackage: String,       // Package name của ứng dụng (vd: com.facebook.orca)
    val appName: String,          // Tên ứng dụng hiển thị (vd: Messenger)
    val sender: String,           // Tên người gửi
    val content: String,          // Nội dung tin nhắn
    val timestamp: Long,          // Thời gian nhận (Unix ms)
    val isPriority: Boolean = false  // Có phải liên hệ ưu tiên không
)
