package com.notifymarquee.ui.history

import android.view.LayoutInflater
import android.view.ViewGroup
import androidx.recyclerview.widget.DiffUtil
import androidx.recyclerview.widget.ListAdapter
import androidx.recyclerview.widget.RecyclerView
import com.notifymarquee.data.database.NotificationEntity
import com.notifymarquee.databinding.ItemNotificationBinding
import com.notifymarquee.utils.TimeUtils

/**
 * RecyclerView Adapter cho danh sách lịch sử thông báo
 */
class NotificationHistoryAdapter(
    private val onDelete: (Long) -> Unit
) : ListAdapter<NotificationEntity, NotificationHistoryAdapter.ViewHolder>(DIFF_CALLBACK) {

    companion object {
        private val DIFF_CALLBACK = object : DiffUtil.ItemCallback<NotificationEntity>() {
            override fun areItemsTheSame(a: NotificationEntity, b: NotificationEntity) = a.id == b.id
            override fun areContentsTheSame(a: NotificationEntity, b: NotificationEntity) = a == b
        }
    }

    inner class ViewHolder(private val binding: ItemNotificationBinding) :
        RecyclerView.ViewHolder(binding.root) {

        fun bind(item: NotificationEntity) {
            binding.tvAppName.text = item.appName
            binding.tvSender.text = item.sender
            binding.tvContent.text = item.content
            binding.tvTime.text = TimeUtils.getRelativeTime(item.timestamp)

            if (item.isPriority) {
                binding.ivPriority.visibility = android.view.View.VISIBLE
            } else {
                binding.ivPriority.visibility = android.view.View.GONE
            }

            binding.btnDelete.setOnClickListener {
                onDelete(item.id)
            }
        }
    }

    override fun onCreateViewHolder(parent: ViewGroup, viewType: Int): ViewHolder {
        val binding = ItemNotificationBinding.inflate(
            LayoutInflater.from(parent.context), parent, false
        )
        return ViewHolder(binding)
    }

    override fun onBindViewHolder(holder: ViewHolder, position: Int) {
        holder.bind(getItem(position))
    }
}
