package com.notifymarquee.ui.settings

import android.view.LayoutInflater
import android.view.ViewGroup
import androidx.recyclerview.widget.DiffUtil
import androidx.recyclerview.widget.ListAdapter
import androidx.recyclerview.widget.RecyclerView
import com.notifymarquee.databinding.ItemAppFilterBinding
import com.notifymarquee.model.AppFilter

/**
 * Adapter cho danh sách bộ lọc ứng dụng trong Cài đặt
 */
class AppFilterAdapter(
    private val onToggle: (index: Int, enabled: Boolean) -> Unit
) : ListAdapter<AppFilter, AppFilterAdapter.ViewHolder>(DIFF) {

    companion object {
        private val DIFF = object : DiffUtil.ItemCallback<AppFilter>() {
            override fun areItemsTheSame(a: AppFilter, b: AppFilter) = a.packageName == b.packageName
            override fun areContentsTheSame(a: AppFilter, b: AppFilter) = a == b
        }
    }

    inner class ViewHolder(private val binding: ItemAppFilterBinding) :
        RecyclerView.ViewHolder(binding.root) {

        fun bind(item: AppFilter, position: Int) {
            binding.tvAppName.text = item.displayName
            binding.tvPackageName.text = item.packageName
            binding.switchEnabled.setOnCheckedChangeListener(null)
            binding.switchEnabled.isChecked = item.isEnabled
            binding.switchEnabled.setOnCheckedChangeListener { _, checked ->
                onToggle(position, checked)
            }
        }
    }

    override fun onCreateViewHolder(parent: ViewGroup, viewType: Int): ViewHolder {
        val binding = ItemAppFilterBinding.inflate(LayoutInflater.from(parent.context), parent, false)
        return ViewHolder(binding)
    }

    override fun onBindViewHolder(holder: ViewHolder, position: Int) {
        holder.bind(getItem(position), position)
    }
}
