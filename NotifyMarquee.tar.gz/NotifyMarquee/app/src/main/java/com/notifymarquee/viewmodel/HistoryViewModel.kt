package com.notifymarquee.viewmodel

import android.app.Application
import androidx.lifecycle.AndroidViewModel
import androidx.lifecycle.LiveData
import androidx.lifecycle.MutableLiveData
import androidx.lifecycle.switchMap
import androidx.lifecycle.viewModelScope
import com.notifymarquee.data.database.NotificationEntity
import com.notifymarquee.data.repository.NotificationRepository
import kotlinx.coroutines.launch

/**
 * ViewModel cho màn hình lịch sử thông báo
 */
class HistoryViewModel(application: Application) : AndroidViewModel(application) {

    private val repository = NotificationRepository(application)

    private val _searchQuery = MutableLiveData("")
    private val _appFilter = MutableLiveData("")

    /**
     * Danh sách thông báo lọc theo từ khóa và package
     */
    val notifications: LiveData<List<NotificationEntity>> = _searchQuery.switchMap { query ->
        repository.searchNotifications(query, _appFilter.value ?: "")
    }

    fun search(query: String) {
        _searchQuery.value = query
    }

    fun filterByApp(packageName: String) {
        _appFilter.value = packageName
        _searchQuery.value = _searchQuery.value // trigger refresh
    }

    fun clearFilter() {
        _appFilter.value = ""
        _searchQuery.value = _searchQuery.value
    }

    fun deleteNotification(id: Long) {
        viewModelScope.launch {
            repository.deleteById(id)
        }
    }

    fun deleteAll() {
        viewModelScope.launch {
            repository.deleteAll()
        }
    }

    /**
     * Xuất dữ liệu dạng CSV text
     */
    suspend fun exportAsCsv(): String {
        val items = repository.getAllForExport()
        val sb = StringBuilder()
        sb.appendLine("Ứng dụng,Người gửi,Nội dung,Thời gian")
        items.forEach { item ->
            sb.appendLine("\"${item.appName}\",\"${item.sender}\",\"${item.content}\",\"${item.timestamp}\"")
        }
        return sb.toString()
    }
}
