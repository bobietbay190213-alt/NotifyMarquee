package com.notifymarquee.ui.settings

import android.os.Bundle
import android.view.View
import android.widget.SeekBar
import android.widget.Toast
import androidx.activity.viewModels
import androidx.appcompat.app.AppCompatActivity
import com.google.android.material.dialog.MaterialAlertDialogBuilder
import com.notifymarquee.R
import com.notifymarquee.databinding.ActivitySettingsBinding
import com.notifymarquee.viewmodel.SettingsViewModel

/**
 * Màn hình cài đặt - điều chỉnh hiệu ứng, bộ lọc ứng dụng và liên hệ ưu tiên
 */
class SettingsActivity : AppCompatActivity() {

    private lateinit var binding: ActivitySettingsBinding
    private val viewModel: SettingsViewModel by viewModels()
    private lateinit var appFilterAdapter: AppFilterAdapter
    private lateinit var priorityAdapter: PriorityContactAdapter

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        binding = ActivitySettingsBinding.inflate(layoutInflater)
        setContentView(binding.root)

        setSupportActionBar(binding.toolbar)
        supportActionBar?.setDisplayHomeAsUpEnabled(true)
        binding.toolbar.setNavigationOnClickListener { finish() }

        setupDisplaySettings()
        setupAppFilters()
        setupPriorityContacts()
        setupObservers()
    }

    // ── Cài đặt hiển thị ─────────────────────────────────────────────────────
    private fun setupDisplaySettings() {
        // Kích thước chữ
        binding.seekTextSize.progress = ((viewModel.textSize - 10f) * 2).toInt().coerceIn(0, 20)
        binding.tvTextSizeValue.text = "${viewModel.textSize.toInt()} sp"
        binding.seekTextSize.setOnSeekBarChangeListener(object : SeekBar.OnSeekBarChangeListener {
            override fun onProgressChanged(sb: SeekBar, p: Int, user: Boolean) {
                val size = 10f + p / 2f
                viewModel.textSize = size
                binding.tvTextSizeValue.text = "${size.toInt()} sp"
            }
            override fun onStartTrackingTouch(sb: SeekBar) {}
            override fun onStopTrackingTouch(sb: SeekBar) {}
        })

        // Tốc độ chạy
        binding.seekScrollSpeed.progress = viewModel.scrollSpeed - 1
        binding.tvScrollSpeedValue.text = "${viewModel.scrollSpeed}"
        binding.seekScrollSpeed.setOnSeekBarChangeListener(object : SeekBar.OnSeekBarChangeListener {
            override fun onProgressChanged(sb: SeekBar, p: Int, user: Boolean) {
                val speed = p + 1
                viewModel.scrollSpeed = speed
                binding.tvScrollSpeedValue.text = "$speed"
            }
            override fun onStartTrackingTouch(sb: SeekBar) {}
            override fun onStopTrackingTouch(sb: SeekBar) {}
        })

        // Độ trong suốt
        binding.seekTransparency.progress = viewModel.transparency
        binding.tvTransparencyValue.text = "${viewModel.transparency}%"
        binding.seekTransparency.setOnSeekBarChangeListener(object : SeekBar.OnSeekBarChangeListener {
            override fun onProgressChanged(sb: SeekBar, p: Int, user: Boolean) {
                viewModel.transparency = p
                binding.tvTransparencyValue.text = "$p%"
            }
            override fun onStartTrackingTouch(sb: SeekBar) {}
            override fun onStopTrackingTouch(sb: SeekBar) {}
        })

        // Thời gian hiển thị
        val durationSec = (viewModel.displayDuration / 1000).toInt()
        binding.seekDisplayDuration.progress = (durationSec - 3).coerceIn(0, 27)
        binding.tvDisplayDurationValue.text = "$durationSec giây"
        binding.seekDisplayDuration.setOnSeekBarChangeListener(object : SeekBar.OnSeekBarChangeListener {
            override fun onProgressChanged(sb: SeekBar, p: Int, user: Boolean) {
                val secs = p + 3
                viewModel.displayDuration = secs * 1000L
                binding.tvDisplayDurationValue.text = "$secs giây"
            }
            override fun onStartTrackingTouch(sb: SeekBar) {}
            override fun onStopTrackingTouch(sb: SeekBar) {}
        })

        // Vị trí dọc
        binding.seekPositionY.progress = viewModel.positionY
        binding.tvPositionYValue.text = "${viewModel.positionY} px"
        binding.seekPositionY.setOnSeekBarChangeListener(object : SeekBar.OnSeekBarChangeListener {
            override fun onProgressChanged(sb: SeekBar, p: Int, user: Boolean) {
                viewModel.positionY = p
                binding.tvPositionYValue.text = "$p px"
            }
            override fun onStartTrackingTouch(sb: SeekBar) {}
            override fun onStopTrackingTouch(sb: SeekBar) {}
        })

        // Hiển thị tên ứng dụng
        binding.switchShowAppName.isChecked = viewModel.showAppName
        binding.switchShowAppName.setOnCheckedChangeListener { _, checked ->
            viewModel.showAppName = checked
        }
    }

    // ── Bộ lọc ứng dụng ──────────────────────────────────────────────────────
    private fun setupAppFilters() {
        appFilterAdapter = AppFilterAdapter { index, enabled ->
            viewModel.updateAppFilter(index, enabled)
        }
        binding.recyclerAppFilters.adapter = appFilterAdapter
        binding.recyclerAppFilters.layoutManager =
            androidx.recyclerview.widget.LinearLayoutManager(this)
        binding.recyclerAppFilters.isNestedScrollingEnabled = false
    }

    // ── Liên hệ ưu tiên ──────────────────────────────────────────────────────
    private fun setupPriorityContacts() {
        priorityAdapter = PriorityContactAdapter { name ->
            viewModel.removePriorityContact(name)
        }
        binding.recyclerPriorityContacts.adapter = priorityAdapter
        binding.recyclerPriorityContacts.layoutManager =
            androidx.recyclerview.widget.LinearLayoutManager(this)
        binding.recyclerPriorityContacts.isNestedScrollingEnabled = false

        binding.btnAddContact.setOnClickListener {
            showAddContactDialog()
        }
    }

    private fun showAddContactDialog() {
        val input = android.widget.EditText(this).apply {
            hint = "Tên người gửi (vd: Nguyễn Văn A)"
            setPadding(48, 24, 48, 24)
        }
        MaterialAlertDialogBuilder(this)
            .setTitle("Thêm liên hệ ưu tiên")
            .setView(input)
            .setPositiveButton("Thêm") { _, _ ->
                val name = input.text.toString().trim()
                if (name.isNotEmpty()) {
                    viewModel.addPriorityContact(name)
                    Toast.makeText(this, "Đã thêm \"$name\"", Toast.LENGTH_SHORT).show()
                }
            }
            .setNegativeButton("Huỷ", null)
            .show()
    }

    private fun setupObservers() {
        viewModel.appFilters.observe(this) { filters ->
            appFilterAdapter.submitList(filters.toList())
        }
        viewModel.priorityContacts.observe(this) { contacts ->
            priorityAdapter.submitList(contacts.toList())
            binding.tvNoPriorityContacts.visibility =
                if (contacts.isEmpty()) View.VISIBLE else View.GONE
        }
    }
}
