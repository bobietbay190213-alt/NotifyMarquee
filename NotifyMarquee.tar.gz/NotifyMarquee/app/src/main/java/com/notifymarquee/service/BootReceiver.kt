package com.notifymarquee.service

import android.content.BroadcastReceiver
import android.content.Context
import android.content.Intent
import android.os.Build
import com.notifymarquee.utils.PreferenceManager

/**
 * BroadcastReceiver tự động khởi động dịch vụ sau khi thiết bị bật lại
 */
class BootReceiver : BroadcastReceiver() {

    override fun onReceive(context: Context, intent: Intent) {
        val action = intent.action ?: return

        if (action == Intent.ACTION_BOOT_COMPLETED ||
            action == Intent.ACTION_MY_PACKAGE_REPLACED ||
            action == "android.intent.action.QUICKBOOT_POWERON"
        ) {
            val prefManager = PreferenceManager(context)

            // Chỉ khởi động lại nếu người dùng đã bật dịch vụ trước đó
            if (prefManager.isServiceEnabled) {
                startOverlayService(context)
            }
        }
    }

    private fun startOverlayService(context: Context) {
        val serviceIntent = Intent(context, MarqueeOverlayService::class.java)
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
            context.startForegroundService(serviceIntent)
        } else {
            context.startService(serviceIntent)
        }
    }
}
