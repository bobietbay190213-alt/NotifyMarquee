package com.notifymarquee.service

import android.app.PendingIntent
import android.app.Service
import android.content.BroadcastReceiver
import android.content.Context
import android.content.Intent
import android.content.IntentFilter
import android.graphics.PixelFormat
import android.os.Build
import android.os.IBinder
import android.view.Gravity
import android.view.LayoutInflater
import android.view.WindowManager
import androidx.core.app.NotificationCompat
import com.notifymarquee.NotifyMarqueeApp
import com.notifymarquee.R
import com.notifymarquee.data.repository.NotificationRepository
import com.notifymarquee.model.NotificationItem
import com.notifymarquee.overlay.MarqueeOverlayView
import com.notifymarquee.ui.home.MainActivity
import com.notifymarquee.utils.PreferenceManager
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.SupervisorJob
import kotlinx.coroutines.launch
import java.util.LinkedList

/**
 * Foreground Service quản lý hiển thị thanh chạy ngang màn hình (Overlay).
 * Chạy liên tục ở nền, hiển thị thông báo dạng marquee trên tất cả ứng dụng.
 */
class MarqueeOverlayService : Service() {

    companion object {
        const val ACTION_STOP = "action_stop_overlay"
        private const val NOTIFICATION_ID = 1001
    }

    private lateinit var windowManager: WindowManager
    private var overlayView: MarqueeOverlayView? = null
    private lateinit var prefManager: PreferenceManager
    private lateinit var repository: NotificationRepository
    private val serviceScope = CoroutineScope(Dispatchers.Main + SupervisorJob())

    // Hàng đợi thông báo chờ hiển thị
    private val notificationQueue: LinkedList<NotificationItem> = LinkedList()
    private var isShowing = false

    /**
     * Receiver nhận thông báo mới từ NotificationListener
     */
    private val notificationReceiver = object : BroadcastReceiver() {
        override fun onReceive(context: Context, intent: Intent) {
            if (intent.action == NotificationListener.ACTION_NEW_NOTIFICATION) {
                val item = NotificationItem(
                    appPackage = intent.getStringExtra(NotificationListener.EXTRA_APP_PACKAGE) ?: "",
                    appName = intent.getStringExtra(NotificationListener.EXTRA_APP_NAME) ?: "",
                    sender = intent.getStringExtra(NotificationListener.EXTRA_SENDER) ?: "",
                    content = intent.getStringExtra(NotificationListener.EXTRA_CONTENT) ?: "",
                    timestamp = intent.getLongExtra(NotificationListener.EXTRA_TIMESTAMP, System.currentTimeMillis()),
                    isPriority = intent.getBooleanExtra(NotificationListener.EXTRA_IS_PRIORITY, false)
                )
                enqueueNotification(item)
            }
        }
    }

    override fun onCreate() {
        super.onCreate()
        prefManager = PreferenceManager(this)
        repository = NotificationRepository(this)
        windowManager = getSystemService(WINDOW_SERVICE) as WindowManager

        registerReceiver(
            notificationReceiver,
            IntentFilter(NotificationListener.ACTION_NEW_NOTIFICATION),
            RECEIVER_NOT_EXPORTED
        )
    }

    override fun onStartCommand(intent: Intent?, flags: Int, startId: Int): Int {
        if (intent?.action == ACTION_STOP) {
            stopSelf()
            return START_NOT_STICKY
        }

        startForeground(NOTIFICATION_ID, buildForegroundNotification())
        return START_STICKY // Tự khởi động lại nếu bị hệ thống giết
    }

    /**
     * Thêm thông báo vào hàng đợi và lưu vào CSDL
     */
    private fun enqueueNotification(item: NotificationItem) {
        // Lưu vào CSDL
        serviceScope.launch(Dispatchers.IO) {
            repository.insert(item)
        }

        // Thêm vào hàng đợi hiển thị
        if (item.isPriority) {
            notificationQueue.addFirst(item) // Ưu tiên lên đầu
        } else {
            notificationQueue.addLast(item)
        }

        // Nếu không đang hiển thị, bắt đầu hiển thị
        if (!isShowing) {
            showNextNotification()
        }
    }

    /**
     * Lấy thông báo tiếp theo trong hàng đợi và hiển thị
     */
    private fun showNextNotification() {
        val item = notificationQueue.pollFirst() ?: run {
            isShowing = false
            return
        }
        isShowing = true
        showOverlay(item)
    }

    /**
     * Hiển thị overlay với thông báo đã cho
     */
    private fun showOverlay(item: NotificationItem) {
        // Xóa overlay cũ nếu còn tồn tại
        removeOverlay()

        val layoutFlag = if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
            WindowManager.LayoutParams.TYPE_APPLICATION_OVERLAY
        } else {
            @Suppress("DEPRECATION")
            WindowManager.LayoutParams.TYPE_PHONE
        }

        val params = WindowManager.LayoutParams(
            WindowManager.LayoutParams.MATCH_PARENT,
            WindowManager.LayoutParams.WRAP_CONTENT,
            layoutFlag,
            WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE or
                    WindowManager.LayoutParams.FLAG_NOT_TOUCH_MODAL or
                    WindowManager.LayoutParams.FLAG_LAYOUT_IN_SCREEN,
            PixelFormat.TRANSLUCENT
        ).apply {
            gravity = Gravity.TOP or Gravity.START
            y = prefManager.positionY
        }

        overlayView = MarqueeOverlayView(this, prefManager).apply {
            setNotification(item)
            setOnMarqueeCompleteListener {
                removeOverlay()
                showNextNotification()
            }
        }

        try {
            windowManager.addView(overlayView, params)
            overlayView?.startMarquee()
        } catch (e: Exception) {
            isShowing = false
        }
    }

    /**
     * Xóa overlay khỏi màn hình
     */
    private fun removeOverlay() {
        overlayView?.let { view ->
            try {
                if (view.isAttachedToWindow) {
                    windowManager.removeView(view)
                }
            } catch (e: Exception) {
                // Bỏ qua nếu view đã bị xóa
            }
        }
        overlayView = null
    }

    /**
     * Tạo thông báo cho Foreground Service
     */
    private fun buildForegroundNotification() = run {
        val openIntent = PendingIntent.getActivity(
            this,
            0,
            Intent(this, MainActivity::class.java),
            PendingIntent.FLAG_IMMUTABLE
        )
        val stopIntent = PendingIntent.getService(
            this,
            1,
            Intent(this, MarqueeOverlayService::class.java).apply { action = ACTION_STOP },
            PendingIntent.FLAG_IMMUTABLE
        )

        NotificationCompat.Builder(this, NotifyMarqueeApp.CHANNEL_ID_FOREGROUND)
            .setContentTitle("NotifyMarquee đang chạy")
            .setContentText("Đang lắng nghe thông báo...")
            .setSmallIcon(R.drawable.ic_notification)
            .setContentIntent(openIntent)
            .addAction(0, "Dừng", stopIntent)
            .setOngoing(true)
            .setSilent(true)
            .build()
    }

    override fun onDestroy() {
        super.onDestroy()
        removeOverlay()
        try {
            unregisterReceiver(notificationReceiver)
        } catch (e: Exception) {
            // Đã unregister
        }
    }

    override fun onBind(intent: Intent?): IBinder? = null
}
