package com.notifymarquee.viewmodel

import android.app.Application
import android.content.Intent
import android.os.Build
import androidx.lifecycle.AndroidViewModel
import androidx.lifecycle.LiveData
import androidx.lifecycle.MutableLiveData
import androidx.lifecycle.viewModelScope
import com.notifymarquee.data.repository.NotificationRepository
import com.notifymarquee.service.MarqueeOverlayService
import com.notifymarquee.utils.PermissionUtils
import com.notifymarquee.utils.PreferenceManager
import com.notifymarquee.utils.TimeUtils
import kotlinx.coroutines.launch

/**
 * ViewModel cho màn hình chính (Home)
 */
class HomeViewModel(application: Application) : AndroidViewModel(application) {

    val prefManager = PreferenceManager(application)
    private val repository = NotificationRepository(application)

    private val _serviceRunning = MutableLiveData(false)
    val serviceRunning: LiveData<Boolean> = _serviceRunning

    private val _permissionStatus = MutableLiveData<PermissionStatus>()
    val permissionStatus: LiveData<PermissionStatus> = _permissionStatus

    val todayNotificationCount: LiveData<Int> =
        repository.getTodayCount(TimeUtils.getStartOfToday())

    /**
     * Kiểm tra trạng thái tất cả quyền
     */
    fun checkPermissions() {
        val ctx = getApplication<Application>()
        _permissionStatus.value = PermissionStatus(
            hasNotificationAccess = PermissionUtils.hasNotificationListenerPermission(ctx),
            hasOverlayPermission = PermissionUtils.hasOverlayPermission(ctx)
        )
    }

    /**
     * Bật/tắt dịch vụ overlay
     */
    fun toggleService(enabled: Boolean) {
        val ctx = getApplication<Application>()
        prefManager.isServiceEnabled = enabled

        if (enabled) {
            startOverlayService(ctx)
        } else {
            stopOverlayService(ctx)
        }
        _serviceRunning.value = enabled
    }

    fun loadServiceState() {
        _serviceRunning.value = prefManager.isServiceEnabled
    }

    private fun startOverlayService(ctx: android.content.Context) {
        val intent = Intent(ctx, MarqueeOverlayService::class.java)
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
            ctx.startForegroundService(intent)
        } else {
            ctx.startService(intent)
        }
    }

    private fun stopOverlayService(ctx: android.content.Context) {
        ctx.stopService(Intent(ctx, MarqueeOverlayService::class.java))
    }

    data class PermissionStatus(
        val hasNotificationAccess: Boolean,
        val hasOverlayPermission: Boolean
    ) {
        val allGranted: Boolean get() = hasNotificationAccess && hasOverlayPermission
    }
}
