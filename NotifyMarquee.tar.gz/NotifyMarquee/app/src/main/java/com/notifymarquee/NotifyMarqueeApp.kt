package com.notifymarquee

import android.app.Application
import android.app.NotificationChannel
import android.app.NotificationManager
import android.os.Build

/**
 * Application class - khởi tạo các thành phần toàn cục
 */
class NotifyMarqueeApp : Application() {

    companion object {
        const val CHANNEL_ID_FOREGROUND = "channel_foreground_service"
        const val CHANNEL_ID_ALERTS = "channel_alerts"
    }

    override fun onCreate() {
        super.onCreate()
        createNotificationChannels()
    }

    /**
     * Tạo các kênh thông báo cho Android 8.0+
     */
    private fun createNotificationChannels() {
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
            val manager = getSystemService(NotificationManager::class.java)

            // Kênh cho Foreground Service
            val foregroundChannel = NotificationChannel(
                CHANNEL_ID_FOREGROUND,
                "Dịch vụ nền",
                NotificationManager.IMPORTANCE_LOW
            ).apply {
                description = "Kênh dùng để duy trì dịch vụ chạy nền"
                setShowBadge(false)
            }

            // Kênh cho cảnh báo / thông báo ưu tiên
            val alertChannel = NotificationChannel(
                CHANNEL_ID_ALERTS,
                "Thông báo ưu tiên",
                NotificationManager.IMPORTANCE_HIGH
            ).apply {
                description = "Kênh cho liên hệ được đánh dấu ưu tiên"
                enableVibration(true)
            }

            manager.createNotificationChannel(foregroundChannel)
            manager.createNotificationChannel(alertChannel)
        }
    }
}
