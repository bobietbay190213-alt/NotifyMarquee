# NotifyMarquee - Android App

Ứng dụng hiển thị thông báo dạng thanh chạy ngang màn hình (Marquee Banner).

## Yêu cầu hệ thống
- Android Studio Hedgehog (2023.1.1) trở lên
- Android SDK 34
- Kotlin 1.9.22
- Java 17

## Cách build

### Bước 1: Mở dự án
1. Mở Android Studio
2. Chọn **File → Open**
3. Trỏ đến thư mục `NotifyMarquee/`
4. Đợi Gradle sync hoàn tất (~2-5 phút lần đầu)

### Bước 2: Build APK
- **Debug**: Build → Build Bundle(s)/APK(s) → Build APK(s)  
- **Release**: Build → Generate Signed Bundle/APK → APK → Nhập keystore

### Bước 3: Cài trên thiết bị
```bash
adb install -r app/build/outputs/apk/debug/app-debug.apk
```

## Cài đặt quyền trên thiết bị

Sau khi cài app, vào **Cài đặt** trên điện thoại và cấp:

1. **Notification Access** (Quyền lắng nghe thông báo):  
   Cài đặt → Ứng dụng → Quyền đặc biệt → Quyền truy cập thông báo → Bật NotifyMarquee

2. **Display Over Other Apps** (Hiển thị trên ứng dụng khác):  
   Cài đặt → Ứng dụng → NotifyMarquee → Hiển thị trên ứng dụng khác → Bật

## Cấu trúc dự án

```
app/src/main/java/com/notifymarquee/
├── NotifyMarqueeApp.kt          # Application class
├── model/
│   ├── NotificationItem.kt     # Model thông báo
│   └── AppFilter.kt            # Model bộ lọc ứng dụng
├── data/
│   ├── database/
│   │   ├── AppDatabase.kt      # Room Database
│   │   ├── NotificationDao.kt  # Data Access Object
│   │   └── NotificationEntity.kt # Entity bảng DB
│   └── repository/
│       └── NotificationRepository.kt # Repository
├── service/
│   ├── NotificationListener.kt  # Lắng nghe thông báo
│   ├── MarqueeOverlayService.kt # Foreground Service overlay
│   └── BootReceiver.kt          # Tự khởi động sau reboot
├── overlay/
│   └── MarqueeOverlayView.kt   # Custom View marquee animation
├── viewmodel/
│   ├── HomeViewModel.kt        # VM màn hình chính
│   ├── HistoryViewModel.kt     # VM lịch sử
│   └── SettingsViewModel.kt    # VM cài đặt
├── ui/
│   ├── home/MainActivity.kt    # Màn hình chính
│   ├── history/
│   │   ├── HistoryActivity.kt
│   │   └── NotificationHistoryAdapter.kt
│   └── settings/
│       ├── SettingsActivity.kt
│       ├── AppFilterAdapter.kt
│       └── PriorityContactAdapter.kt
└── utils/
    ├── PreferenceManager.kt    # Quản lý SharedPreferences
    ├── PermissionUtils.kt      # Kiểm tra & yêu cầu quyền
    └── TimeUtils.kt            # Tiện ích thời gian
```

## Kiến trúc

- **Pattern**: MVVM (Model - View - ViewModel)
- **Database**: Room (SQLite)
- **Async**: Kotlin Coroutines + LiveData
- **UI**: Material Design 3
- **Service**: NotificationListenerService + Foreground Service
- **Overlay**: WindowManager với TYPE_APPLICATION_OVERLAY

## Tính năng chính

| Tính năng | Chi tiết |
|-----------|----------|
| Đọc thông báo | NotificationListenerService - không cần root |
| Hiển thị Marquee | Chạy từ phải sang trái, 60 FPS mượt |
| Hoạt động trên mọi app | Overlay với TYPE_APPLICATION_OVERLAY |
| Không block cảm ứng | FLAG_NOT_TOUCHABLE |
| Chạy nền ổn định | Foreground Service + START_STICKY |
| Tự khởi động | BroadcastReceiver BOOT_COMPLETED |
| Bộ lọc ứng dụng | Chọn từng app (Messenger, TikTok, Zalo...) |
| Liên hệ ưu tiên | Hiển thị đầu hàng đợi |
| Lịch sử thông báo | Room DB + tìm kiếm + xuất CSV |
| Cài đặt đầy đủ | Kích thước, tốc độ, màu, vị trí... |
